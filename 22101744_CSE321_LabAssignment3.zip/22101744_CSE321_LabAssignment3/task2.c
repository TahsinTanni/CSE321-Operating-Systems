#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/wait.h>


struct msg{
	long int type;
	char txt[6];
	};
int main(){
        char w_name[20];
        
	pid_t otp;
	pid_t mail;
	
	printf("Please enter the workspace name:\n");
	scanf("%s",w_name);
	int res= strcmp(w_name, "cse321");
	if (res != 0) {
        printf("Invalid workspace name\n");
        exit(0);} 
        
        struct msg w_data;
        int m_id=msgget((key_t)12,0666|IPC_CREAT);
        
        w_data.type = 5 ; 
	strcpy(w_data.txt,w_name);
	int login= msgsnd(m_id,(void *)&w_data,sizeof(w_data.txt),0);
	printf("Workspace name sent to otp generator from log in: %s\n",w_data.txt);
	
	otp = fork();
	if (otp<0){
	perror("Fork");
	}
	else if (otp==0){ 
		msgrcv(m_id,(void *)&w_data,sizeof(w_data.txt),5,IPC_NOWAIT);
		printf("OTP generator received workspace name from log in: %s\n", w_data.txt);
		
		int o_tp = getpid();
		
		w_data.type = 10;
		sprintf(w_data.txt, "%d", o_tp);
		
		msgsnd(m_id,(void *)&w_data,sizeof(w_data.txt),0);
		printf("OTP sent to log in from OTP generator: %s\n", w_data.txt);
		
		
		w_data.type = 15;
		sprintf(w_data.txt, "%d", o_tp); 

		msgsnd(m_id,(void *)&w_data,sizeof(w_data.txt),0);
		printf("OTP sent to mail from OTP generator: %s\n", w_data.txt);
		
		mail = fork();
		if (mail<0){
		perror("fork");
		}
		
		else if (mail==0){
		
			msgrcv(m_id,(void *)&w_data,sizeof(w_data.txt),15,IPC_NOWAIT); 
			printf("Mail received OTP from OTP generator: %s\n", w_data.txt);
			
			char buffer[20];
			strcpy(buffer, w_data.txt);
				      
			w_data.type = 20;
			strcpy(w_data.txt, buffer);
			msgsnd(m_id,(void *)&w_data,sizeof(w_data.txt),0);
			printf("Mail sent OTP to log in: %s\n", w_data.txt);
			exit(0);	
		}
		
		else{
		wait(NULL); 
		exit(0);
		} 
			
	} 
	else{

	
	wait(NULL); 
	
	char t1[20];
	char t2[20];
	
	

        msgrcv(m_id,(void *)&w_data,sizeof(w_data.txt),10,IPC_NOWAIT); 
        printf("Log in received OTP from OTP generator: %s\n", w_data.txt);
        
        strcpy(t1,w_data.txt);
	
        msgrcv(m_id,(void *)&w_data,sizeof(w_data.txt),20,IPC_NOWAIT);  
        printf("Log in received OTP from mail: %s\n", w_data.txt);
        
        strcpy(t2,w_data.txt);
        

        if (strcmp(t1, t2) == 0) {
        printf("OTP Verified\n");
        } 
        else {
        printf("OTP Incorrect\n");
        }
        msgctl(m_id, IPC_RMID, NULL);
	} 
return 0;
}
