#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>

struct shared {
    char sel[100];
    int b;
};

int main() {
    int fd[2];
    if (pipe(fd) == -1) {
        perror("Pipe creation failed");
        exit(1);
    }

    int sm_id;
    struct shared *sm;

    
    sm_id = shmget((key_t)321, 1024, 0666 | IPC_CREAT);
    if (sm_id == -1) {
        perror("Shared memory creation failed");
        exit(1);
    }

    sm = (struct shared *) shmat(sm_id, NULL, 0);
    sm->b = 1000; 

    
    printf("Provide Your Input From Given Options:\n");
    printf("1. Type a to Add Money\n");
    printf("2. Type w to Withdraw Money\n");
    printf("3. Type c to Check Balance\n");

    char inp[10];
    scanf("%s", inp);
    strcpy(sm->sel, inp);

    printf("Your selection: %s\n", sm->sel);

    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        exit(1);
    }
    else if (pid == 0) {
       
        char s[2];
        strcpy(s, sm->sel);

        if (strcmp(s, "a") == 0) {
            int amount1;
            printf("Enter amount to be added:\n");
            scanf("%d", &amount1);
            if (amount1 > 0) {
                sm->b += amount1;
                printf("Balance added successfully\n");
                printf("Updated balance after addition:\n%d\n", sm->b);
            } else {
                printf("Adding failed, Invalid amount\n");
            }
        }
        else if (strcmp(s, "w") == 0) {
            int amount2;
            printf("Enter amount to be withdrawn:\n");
            scanf("%d", &amount2);
            if (amount2 > 0 && amount2 <= sm->b) {
                sm->b -= amount2;
                printf("Balance withdrawn successfully\n");
                printf("Updated balance after withdrawal:\n%d\n", sm->b);
            } else {
                printf("Withdrawal failed, Invalid amount\n");
            }
        }
        else if (strcmp(s, "c") == 0) {
            printf("Your current balance is:\n%d\n", sm->b);
        }
        else {
            printf("Invalid selection\n");
        }

       
        close(fd[0]);
        char s1[] = "Thank you for using";
        write(fd[1], s1, strlen(s1));
        close(fd[1]);

        exit(0);
    }
    else {
       
        wait(NULL);

        char buffer[100];
        close(fd[1]);
        int n = read(fd[0], buffer, sizeof(buffer) - 1);
        buffer[n] = '\0';
        printf("%s\n", buffer);
        close(fd[0]);

        
        shmctl(sm_id, IPC_RMID, NULL);
    }

    return 0;
}