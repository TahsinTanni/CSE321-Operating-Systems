#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <stdlib.h>

#define NUM_STUDENTS 10
#define NUM_CHAIRS 3

int waiting_students = 0;
int served_students = 0;
int next_student_id = 0;

pthread_mutex_t lobby_mutex;
sem_t student_sem;
sem_t tutor_sem;
sem_t consultation_sem;

void random_delay() {
    sleep(1); 
}

void* tutor(void* arg) {
    while (served_students < NUM_STUDENTS) {
        sem_wait(&student_sem);

        pthread_mutex_lock(&lobby_mutex);
        if (waiting_students > 0) {
            waiting_students--;
            printf("A waiting student started getting consultation\n");
            printf("Number of students now waiting: %d\n", waiting_students);
            printf("ST giving consultation\n");
            pthread_mutex_unlock(&lobby_mutex);

            sem_post(&tutor_sem);

            random_delay();

            sem_wait(&consultation_sem);
        } else {
            pthread_mutex_unlock(&lobby_mutex);
        }
    }
    return NULL;
}

void* student(void* arg) {
    int id = *(int*)arg;
    random_delay();

    pthread_mutex_lock(&lobby_mutex);
    if (waiting_students >= NUM_CHAIRS) {
        printf("No chairs remaining in lobby. Student %d Leaving.....\n", id);
        pthread_mutex_unlock(&lobby_mutex);
        printf("Student %d finished getting consultation and left\n", id);
        pthread_mutex_lock(&lobby_mutex);
        served_students++;
        pthread_mutex_unlock(&lobby_mutex);
        return NULL;
    }

    printf("Student %d started waiting for consultation\n", id);
    waiting_students++;
    pthread_mutex_unlock(&lobby_mutex);

    sem_post(&student_sem);
    sem_wait(&tutor_sem);

    pthread_mutex_lock(&lobby_mutex);
    printf("Student %d is getting consultation\n", id);
    pthread_mutex_unlock(&lobby_mutex);

    sleep(1);

    printf("Student %d finished getting consultation and left\n", id);

    pthread_mutex_lock(&lobby_mutex);
    served_students++;
    printf("Number of served students: %d\n", served_students);
    pthread_mutex_unlock(&lobby_mutex);

    sem_post(&consultation_sem);

    return NULL;
}

int main() {
    srand(time(NULL));
    pthread_t tutor_thread, student_threads[NUM_STUDENTS];
    int student_ids[NUM_STUDENTS];

    pthread_mutex_init(&lobby_mutex, NULL);
    sem_init(&student_sem, 0, 0);
    sem_init(&tutor_sem, 0, 0);
    sem_init(&consultation_sem, 0, 0);

    pthread_create(&tutor_thread, NULL, tutor, NULL);

    for (int i = 0; i < NUM_STUDENTS; i++) {
        student_ids[i] = i;
        pthread_create(&student_threads[i], NULL, student, &student_ids[i]);
    }

    for (int i = 0; i < NUM_STUDENTS; i++) {
        pthread_join(student_threads[i], NULL);
    }

    pthread_join(tutor_thread, NULL);

    pthread_mutex_destroy(&lobby_mutex);
    sem_destroy(&student_sem);
    sem_destroy(&tutor_sem);
    sem_destroy(&consultation_sem);

    return 0;
}
