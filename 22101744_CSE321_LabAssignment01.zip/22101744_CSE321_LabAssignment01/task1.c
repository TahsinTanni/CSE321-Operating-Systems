#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

int main(int argc, char *argv[]) {

    
    if (argc < 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1; // Exit with error
    }

    FILE *fpointer = fopen(argv[1], "w");
    if (fpointer == NULL) {
        perror("Error opening file");
        return 1;
    }

    int count = 0;
    while (1) {
        char string[100];
        printf("Please enter the string: ");
        fgets(string, sizeof(string), stdin);

    
        string[strcspn(string, "\n")] = 0;

   
        if (strcmp(string, "-1") == 0) {
            break;
        }

        fprintf(fpointer, "%s\n", string);
        count++;
    }

    fclose(fpointer);
    return 0;
}