
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/file.h>  

#define FILENAME "process_count.txt"

void increment_process_count() {
    int fpointer = open(FILENAME, O_RDWR | O_CREAT, 0666);
  
    int count = 0;
    lseek(fpointer, 0, SEEK_SET);
    read(fpointer, &count, sizeof(int));

    count++;

    lseek(fpointer, 0, SEEK_SET);
    write(fpointer, &count, sizeof(int));
    flock(fpointer, LOCK_UN);
    close(fpointer);
}

int main() {
    pid_t a, b,c,d,e,f;
    int fpointer = open(FILENAME, O_RDWR | O_CREAT | O_TRUNC, 0666);
    int init_count = 0;
    write(fpointer, &init_count, sizeof(int));
    close(fpointer);

    a = fork();
    if (a<0){
    	printf("Error");
    }
    else if (a==0){
        increment_process_count();
        printf("%d:\n",getpid());
    	if (getpid()%2!=0){
    		d=fork();
    		//increment_process_count();
    		if (d==0){
    		   increment_process_count();
    		}
    		else if (d>0){
    			wait(NULL);
    		}
    		else{
    			printf("err");
    		}
    		
    	}
    }
    else{
    	b=fork();
    	if (b<0){
    		printf("Error");
    	}
    	else if(b==0){
    		increment_process_count();
    		printf("%d:\n",getpid());
    		if (getpid()%2!=0){
    			e=fork();
    			//increment_process_count();
    			if (e==0){
    		   		increment_process_count();
    			}
    			else if (e>0){
    				wait(NULL);
    			}
    			else{
    				printf("err");
    			}
    			
    			
    	        }	
    	}
    	else{
    		c=fork();
    		if (c<0){
    			printf("Error");		
    		}
    		else if(c==0){
    			increment_process_count();
    			printf("%d:\n",getpid());
    			if (getpid()%2!=0){
    				f=fork();
    				//increment_process_count();
    				if (f==0){
    		   			increment_process_count();
    				}
    				else if (f>0){
    					wait(NULL);
    				}
    				else{
    				 printf("err");
    				}
    			
    				
    	        }else{
    	        	 // Wait for all children
        		wait(NULL);
        		increment_process_count();
        		fpointer = open(FILENAME, O_RDONLY);
        		int total_processes = 0;
        		read(fpointer, &total_processes, sizeof(int));
        		close(fpointer);

                        printf("Total processes created: %d\n", total_processes);
    	        	
    	        }
    	       
    	}
    		
    	}
    	
    }



    return 0;
}