#include <stdio.h>      
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
    int a,b,c,d;
    pid_t v,w,x,y,z;
    v = 0;
    printf("1.Parent process ID:%d\n", v);
    a = fork();

    if (a < 0){
        printf("error\n");
    }
    else if (a == 0){
        sleep(2);
        w = getpid();
        printf("2.Child process ID:%d\n", w);
        b = fork();
        if (b < 0){
            printf("error\n");
        }
        else if (b == 0){
            x = getpid();
            printf("3.Grand Child process ID:%d\n", x);
        }
        else{
            c = fork();
            if (c < 0){
                printf("error\n");
            }
            else if (c == 0){
                y = getpid();
                printf("4.Grand Child process ID:%d\n", y);
            }
            else{
                d = fork();
                if (d < 0){
                    printf("error\n");
                }
                else if (d == 0){
                    z = getpid();
                    printf("5.Grand Child process ID:%d\n", z);
                }
                else{
                    wait(NULL);
                    wait(NULL);
                    wait(NULL);
                }
            }
        }
    }
    else{
        wait(NULL);
    }
    return 0;
}