#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
    if (argc < 2) {
        printf("Usage: %s num1 num2 ...\n", argv[0]);
        return 1;
    }
    printf("Odd/Even status:\n");
    for (int i = 1; i < argc; i++){
        int val = atoi(argv[i]);
        if (val % 2 == 0) {
            printf("%d: EVEN\n", val);
        } else {
            printf("%d: ODD\n", val);
        }
    }
    return 0;
}