#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    printf("Enter 7 numbers:\n");

    int int1, int2, int3, int4, int5, int6, int7;
    scanf("%d%d%d%d%d%d%d", &int1, &int2, &int3, &int4, &int5, &int6, &int7);

    char arg1[12], arg2[12], arg3[12], arg4[12], arg5[12], arg6[12], arg7[12];
    sprintf(arg1, "%d", int1);
    sprintf(arg2, "%d", int2);
    sprintf(arg3, "%d", int3);
    sprintf(arg4, "%d", int4);
    sprintf(arg5, "%d", int5);
    sprintf(arg6, "%d", int6);
    sprintf(arg7, "%d", int7);

    pid_t pid = fork();
    if (pid < 0) {
        printf("Fork failed\n");
        return 1;
    }
    else if (pid == 0) {
        // Child er sort program
        execl("./sort", "sort", arg1, arg2, arg3, arg4, arg5, arg6, arg7, NULL);
        perror("execl failed");
        exit(1);
    }
    else {
      
        wait(NULL);

        // Parent er oddeven program 
        execl("./oddeven", "oddeven", arg1, arg2, arg3, arg4, arg5, arg6, arg7, NULL);
        perror("execl failed");
        exit(1);
    }
    return 0;
}