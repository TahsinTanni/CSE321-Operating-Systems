#include <stdio.h>      
#include <unistd.h>    
#include <sys/types.h>  
#include <sys/wait.h>   

int main() {
    pid_t a, b;

    a = fork();  

    if (a < 0) {
       
        printf("Error creating child process\n");
        return 1;
    }
    else if (a == 0) {

        sleep(1);  

        b = fork();  

        if (b < 0) {
            printf("Error creating grandchild process\n");
            return 1;
        }
        else if (b == 0) {
            
            printf("I am grandchild\n");
        }
        else {
           
            wait(NULL);
            printf("I am child\n");
        }
    }
    else {
        
        wait(NULL);
        printf("I am parent\n");
    }

    return 0;
}